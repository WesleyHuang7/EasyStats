#' Summary Stats
#' @export
summary_stats <- function(x) {
  if (!is.numeric(x)) stop("Input must be numeric")
  list(
    mean = mean(x, na.rm = TRUE),
    median = median(x, na.rm = TRUE),
    min = min(x, na.rm = TRUE),
    max = max(x, na.rm = TRUE),
    sd = sd(x, na.rm = TRUE)
  )
}
#' Remove Missing Values
#' @export
remove_missing <- function(x) {
  x[!is.na(x)]
}

#' Simple Scatter Plot
#' @export
simple_scatter <- function(x, y) {
  if (!is.numeric(x) || !is.numeric(y)) {
    stop("Both inputs must be numeric")
  }
  plot(x, y, pch = 19, main = "Simple Scatter Plot")
}
