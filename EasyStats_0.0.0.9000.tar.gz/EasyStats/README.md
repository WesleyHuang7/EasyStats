# EasyStats

EasyStats is a simple R package designed to help with basic data cleaning, summary statistics, and visualization. This package was created as a final project for LIS4370 to demonstrate how an R package is structured and documented.

## Functions

The package includes three main functions:

1. summary_stats()  
   Returns the mean, median, minimum, maximum, and standard deviation of a numeric vector.

2. remove_missing()  
   Removes missing values (NA) from a vector.

3. simple_scatter()  
   Creates a basic scatter plot using two numeric vectors.

## Example Usage

```r
library(EasyStats)

numbers <- c(10, 20, 30, NA, 40, 50)

remove_missing(numbers)

summary_stats(numbers)

x <- c(1, 2, 3, 4, 5)
y <- c(2, 4, 6, 8, 10)

simple_scatter(x, y)
```

## Description

This package includes basic tools that are useful for beginners working with data in R. It focuses on simplicity and ease of use.

## License

This package uses the CC0-1.0 license.